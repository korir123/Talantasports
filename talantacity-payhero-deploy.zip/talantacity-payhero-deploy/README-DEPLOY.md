# TalantaCity + PayHero deployment

## Important before selling tickets
This package adds a server-side PayHero STK Push and transaction-status check. The payment callback is treated only as a notification; the function verifies status directly with PayHero before a ticket reference is issued. The existing seat map and sold-seat list are still demo data: they are not a shared, real-time inventory and do not prevent two customers selecting the same seat. Confirm event authorization, venue, dates, and seat inventory before opening sales.

## Upload to GitHub
1. Open your `talantacity-website` repository.
2. Choose **Add file → Upload files**.
3. Upload everything in this folder, keeping the `netlify/functions/` folder structure.
4. Commit the files to the main branch.

## Connect Netlify
1. In Netlify, choose **Add new project → Import an existing project**.
2. Choose GitHub and authorize Netlify.
3. Select `talantacity-website`. Build settings: publish directory `.`; functions directory `netlify/functions`.
4. Deploy. You can keep the current site domain by attaching `talantasport.com` and `talantasport.netlify.app` to the new Netlify site (Netlify may instead let you link the existing site to the repository).

## Set environment variables in Netlify
Site configuration → Environment variables:
- `PAYHERO_API_USERNAME` = your PayHero API username
- `PAYHERO_API_PASSWORD` = your PayHero API password
- `PAYHERO_CHANNEL_ID` = `14990`

Never put these values in HTML, GitHub, or chat. Save them in Netlify only, then redeploy.

## Test safely
First request PayHero test credits or confirm test/live mode with PayHero support. Do not use a real customer payment until the channel is confirmed active and test checkout has been completed end-to-end. Verify successful payment, failed payment, cancellation, and duplicate callback handling.
