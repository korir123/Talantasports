import { store, json, authHeader } from "./_shared.mjs";
import { randomBytes } from "node:crypto";
export default async (req) => {
  if(req.method!=="POST") return json({error:"Method not allowed"},405);
  try {
    const payload=await req.json();
    const response=payload?.response||{};
    const external=String(response.ExternalReference||payload?.ExternalReference||"");
    if(!/^TAL-[0-9a-f-]{36}$/i.test(external)) return json({received:true});
    const db=store(); const raw=await db.get(external); if(!raw) return json({received:true});
    const order=JSON.parse(raw);
    // Treat callback only as a notification. Verify the transaction independently with PayHero.
    const ref=order.payheroReference||response.CheckoutRequestID||external;
    const check=await fetch("https://backend.payhero.co.ke/api/v2/transaction-status?reference="+encodeURIComponent(ref),{headers:{"Authorization":authHeader()}});
    if(check.ok){const result=await check.json();
      if(String(result.status||"").toUpperCase()==="SUCCESS" && result.success===true){ order.status="SUCCESS"; order.ticket=order.ticket||{code:"TAL-"+randomBytes(5).toString("hex").toUpperCase(),issuedAt:new Date().toISOString()}; order.mpesaReceiptNumber=result.provider_reference||result.third_party_reference||null; }
      else if(String(result.status||"").toUpperCase()==="FAILED") order.status="FAILED";
      await db.set(external,JSON.stringify(order));
    }
    return json({received:true});
  } catch { return json({received:true}); }
};
