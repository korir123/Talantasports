import { store, json, authHeader } from "./_shared.mjs";
import { randomBytes } from "node:crypto";
export default async (req) => {
  if(req.method!=="GET") return json({error:"Method not allowed"},405);
  try {
    const url=new URL(req.url); const reference=url.searchParams.get("reference");
    if(!reference || !/^TAL-[0-9a-f-]{36}$/i.test(reference)) return json({error:"Invalid reference"},400);
    const db=store(); const raw=await db.get(reference); if(!raw) return json({error:"Order not found"},404);
    const order=JSON.parse(raw);
    if(order.status==="SUCCESS" && !order.ticket){ order.ticket={code:"TAL-"+randomBytes(5).toString("hex").toUpperCase(),issuedAt:new Date().toISOString()}; await db.set(reference,JSON.stringify(order)); }
    if(order.status!=="SUCCESS" && order.status!=="FAILED") {
      const ref=order.payheroReference||reference;
      const r=await fetch("https://backend.payhero.co.ke/api/v2/transaction-status?reference="+encodeURIComponent(ref),{headers:{"Authorization":authHeader()}});
      if(r.ok){const status=await r.json();
        if(String(status.status||"").toUpperCase()==="SUCCESS" && status.success===true){
          order.status="SUCCESS"; order.ticket=order.ticket||{code:"TAL-"+randomBytes(5).toString("hex").toUpperCase(),issuedAt:new Date().toISOString()};
          order.mpesaReceiptNumber=status.provider_reference||status.third_party_reference||null;
        } else if(String(status.status||"").toUpperCase()==="FAILED") order.status="FAILED";
        await db.set(reference,JSON.stringify(order));
      }
    }
    return json({status:order.status,ticket:order.status==="SUCCESS"?order.ticket:null});
  } catch(e){return json({error:e.message||"Unable to check payment status"},500);}
};
