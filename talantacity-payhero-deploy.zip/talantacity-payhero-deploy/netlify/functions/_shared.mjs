import { getStore } from "@netlify/blobs";
export const store = () => getStore({ name: "talanta-orders", consistency: "strong" });
export const json = (data, status=200) => new Response(JSON.stringify(data), { status, headers: { "content-type":"application/json", "cache-control":"no-store" } });
export const authHeader = () => {
  const u=process.env.PAYHERO_API_USERNAME, p=process.env.PAYHERO_API_PASSWORD;
  if(!u || !p) throw new Error("PayHero API credentials are not configured in Netlify.");
  return "Basic "+Buffer.from(`${u}:${p}`).toString("base64");
};
export const prices = { Regular:2500, VIP:5000, VVIP:15000 };
