import { randomUUID } from "node:crypto";
import { store, json, authHeader, prices } from "./_shared.mjs";

export default async (req) => {
  if(req.method!=="POST") return json({error:"Method not allowed"},405);
  try {
    const body=await req.json();
    const {ticketType,seats,phone}=body||{};
    if(!Object.hasOwn(prices,ticketType) || !Array.isArray(seats) || seats.length<1 || seats.length>8 || seats.some(s=>typeof s!=="string" || s.length>40)) return json({error:"Invalid ticket selection."},400);
    const normalized=String(phone||"").replace(/[\s-]/g,"");
    if(!/^(?:0|254|\+254)(?:7|1)\d{8}$/.test(normalized)) return json({error:"Enter a valid Kenyan M-Pesa phone number."},400);
    const amount=prices[ticketType]*seats.length;
    const reference="TAL-"+randomUUID();
    const base=(process.env.URL||process.env.DEPLOY_PRIME_URL||"").replace(/\/$/,"");
    if(!base) return json({error:"Netlify site URL is not available."},500);
    const order={reference,ticketType,seats,phone:normalized,amount,status:"QUEUED",createdAt:new Date().toISOString()};
    const db=store(); await db.set(reference,JSON.stringify(order));
    const response=await fetch("https://backend.payhero.co.ke/api/v2/payments",{
      method:"POST",headers:{"Authorization":authHeader(),"Content-Type":"application/json"},
      body:JSON.stringify({amount,phone_number:normalized,channel_id:Number(process.env.PAYHERO_CHANNEL_ID||14990),provider:"m-pesa",external_reference:reference,customer_name:"TalantaCity Customer",callback_url:base+"/.netlify/functions/payhero-callback"})
    });
    const result=await response.json().catch(()=>({}));
    if(!response.ok || result.success===false){order.status="FAILED";order.error="PayHero rejected the payment request";await db.set(reference,JSON.stringify(order));return json({error:result.error_message||result.message||"PayHero could not start the payment."},502);}
    order.payheroReference=result.reference||result.CheckoutRequestID||reference;
    order.checkoutRequestID=result.CheckoutRequestID||null;
    await db.set(reference,JSON.stringify(order));
    return json({success:true,reference});
  } catch(e) { return json({error:e.message||"Unable to start payment."},500); }
};
